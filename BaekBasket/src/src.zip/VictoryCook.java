import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class VictoryCook extends JFrame{
	private JLabel la=new JLabel();
	private JLabel victoryLa=new JLabel("우     승");
	
	public VictoryCook(ImageIcon img) {
		
		
		setSize(800,600);
		Font f1;
		f1 = new Font("돋움", Font.BOLD, 30);
		Font f2;
		f2 = new Font("돋움", Font.BOLD, 50);
		
		Container c = getContentPane();
		c.setLayout(null);
		JButton btn =new JButton(img.toString(),img);
		btn.setSize(500,300);
		btn.setLocation(145,200);
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JButton btn=(JButton)e.getSource();
				for(int i=0;i<MainFrame.index;i++) {
					if(btn.getText().equals(MainFrame.f[i].getName())) {
						new RecipeInterface(MainFrame.f[i]);
						dispose();
					}
					
				}
				
			}
		});
		victoryLa.setFont(f2);
		victoryLa.setSize(200,100);
		victoryLa.setLocation(300,1);
		
		la.setFont(f1);
		la.setLocation(300,50);
		la.setSize(400,200);
		la.setText(img.toString());
		c.add(la);
		c.add(btn);
		c.add(victoryLa);

		setVisible(true);

	}
}
